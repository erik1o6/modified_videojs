<?php

$file_content = "This is my file!";

file_put_contents('test20.html', $file_content);

?>
